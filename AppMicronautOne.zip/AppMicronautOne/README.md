
User Guide
https://docs.micronaut.io/latest/guide/


Micronaut HTTP Client documentation
https://docs.micronaut.io/latest/guide/index.html#httpClient


General Guide
https://guides.micronaut.io/index.html


API Reference
https://docs.micronaut.io/latest/api/



echo "function bldQ() {" >> ~/.bashrc
echo "}"  >> ~/.bashrc

echo "function callQ() {" >> ~/.bashrc
echo "}"  >> ~/.bashrc

echo "function getQ() {" >> ~/.bashrc
echo "}"  >> ~/.bashrc

echo "function okQ() {" >> ~/.bashrc
echo "}"  >> ~/.bashrc

echo "function putQ() {" >> ~/.bashrc
echo "}"  >> ~/.bashrc

echo "function postQ() {" >> ~/.bashrc
echo "}"  >> ~/.bashrc

package net.greg.expo.micronaut;

import io.micronaut.runtime.Micronaut;

public final class App {

  public static void main(String ... any) {
    Micronaut.run(App.class, any);
  }
}

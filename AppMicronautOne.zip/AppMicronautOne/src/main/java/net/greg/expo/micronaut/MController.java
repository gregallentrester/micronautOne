package net.greg.expo.micronaut;

import io.micronaut.http.MediaType;

import io.micronaut.http.annotation.*;


@Controller("/signal")
public class MController {

  /*
    curl -H 'Content-Type: text/plain' http://localhost:8080/signal/$1
  */
  @Get
  @Produces(MediaType.TEXT_PLAIN)
  public String alert() {
    return GRN + "\n\nMethod:GET " + NC + "| Handler: alert() ... \n\n";
  }

  /*
    curl -H 'Content-Type: text/plain' http://localhost:8080/signal/freddy
  */
  @Get("/{name}")
  @Produces(MediaType.TEXT_PLAIN)
  public String hello(String name) {
    return GRN + "\n\nMethod:GET " + NC + "| Handler: hello() | param=name: " + name + "\n\n";
  }

  /*
    curl -H 'Content-Type: text/plain' -X POST http://localhost:8080/signal/freddyddads
  */
  @Post(value = "/{name}", consumes = MediaType.TEXT_PLAIN)
  public String remember(@Body String name) {
    return GRN + "\n\nMethod:POST " + NC + "| Handler: remember() | param=name: " + name + "\n\n";
  }

  /*
    curl -H 'Content-Type: text/plain' -X PUT http://localhost:8080/signal/freddyddads
  */
  @Put(value = "/{name}", consumes = MediaType.TEXT_PLAIN)
  public String recall(@Body String name) {
    return GRN + "\n\nMethod:PUT " + NC + "| Handler: recall() | param=name: " + name + "\n\n";
  }


  public static final String RED = "\033[1;91m";
  public static final String GRN = "\033[1;92m";
  public static final String YLW = "\033[1;93m";
  public static final String NC = "\u001B[0m";
}
